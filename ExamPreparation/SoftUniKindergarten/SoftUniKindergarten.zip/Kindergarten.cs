﻿using Microsoft.Win32;
using System.Collections.Generic;
using System.Linq;
using SoftUniKindergarten;
using System.Text;
using System;

namespace SoftUniKindergarten
{
    public class Kindergarten
    {
        readonly List<Child> registry = new List<Child>();
        public Kindergarten(string name, int capacity)
        {
            Name = name;
            Capacity = capacity;
            Registry= new List<Child>();
        }

        public string Name { get; set; }
        public int Capacity { get; set; }
        public List<Child> Registry { get; set; }


        public bool AddChild(Child child)
        {
            if(Registry.Count<Capacity)
            {
                Registry.Add(child);
             
                return true;
            }
            else
            {
                return false;
            }
        }
        //  public  bool RemoveChild(string childFullName)



        public   bool GetChild(string childFullName)
        {
             registry=(List<Child>)registry.Where($"{e => e.FirstName} {e => e.LastName}" == childFullName);
            return true;
        }






        public int ChildrenCount { get { return Registry.Count; } }

       
        //   public string GetChild(string childFullName)

        public string RegistryReport()
        {
            StringBuilder sb = new();
            sb.AppendLine($"Registered children in {Name}:");
            Registry = (List<Child>)registry.OrderByDescending(e => e.Age).ThenBy(e => e.LastName).ThenBy(e => e.FirstName);
            
           
                sb.AppendLine(string.Join(Environment.NewLine, registry));
            
            return sb.ToString().Trim();
        }

    }
}
